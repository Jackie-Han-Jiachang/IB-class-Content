package School;

public class Homerooms extends Rooms{
    private int numbers;


    Homerooms(int numbers) {
        super(numbers);
    }

    public int getNumbers(){
        return numbers;
    }
}

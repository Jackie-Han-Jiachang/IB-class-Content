package School;

public class Rooms {
    private int numbers;

    Rooms(int numbers){
        this.numbers = numbers;
    }

    public int getNumbers(){
        return this.numbers;
    }
}
